# Projet2023

Structure du projet sur Github :

On fait sa partie sur une branche différente et quand on a fini on la merge avec le main

Attention : On ne code pas à partir du main !
